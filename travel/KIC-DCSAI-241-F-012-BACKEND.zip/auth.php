<?php
// Database connection
$host = "localhost";
$dbname = "sri_lanka_tourism"; // Updated to connect to the sri_lanka_tourism database
$username = "root";           // Database username
$password = "";               // Database password

// Initialize variables for feedback modal
$message = "";
$success = false;

try {
    // Establish a connection to the sri_lanka_tourism database using PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Handle connection error
    die("Database connection failed: " . $e->getMessage());
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['signup'])) {
        // Sign-up logic
        $fullName = htmlspecialchars($_POST['full-name'] ?? '');
        $email = htmlspecialchars($_POST['email'] ?? '');
        $password = password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT);

        try {
            // Insert data into the `users` table in sri_lanka_tourism database
            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$fullName, $email, $password]);

            // Redirect to signin.html after successful signup
            header("Location: signin.html");
            exit();
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $message = "Email already exists. Please use a different email.";
            } else {
                $message = "Error: " . $e->getMessage();
            }
            $success = false;
        }
    } elseif (isset($_POST['signin'])) {
        // Sign-in logic
        $email = htmlspecialchars($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        // Query to select user data from the `users` table in sri_lanka_tourism database
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $message = "Sign-in successful! Welcome back.";
            $success = true;
        } else {
            $message = "Invalid email or password. Please try again.";
            $success = false;
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PearlsEscape.lk - Authentication</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            display: <?php echo $message ? 'flex' : 'none'; ?>;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 400px;
            text-align: center;
        }

        .modal-message {
            font-size: 18px;
            color: <?php echo $success ? 'green' : 'red'; ?>;
        }

        .close-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="modal-overlay">
        <div class="modal">
            <div class="modal-message"><?php echo $message; ?></div>
            <a href="<?php echo $success ? 'index.html' : $_SERVER['HTTP_REFERER']; ?>" class="close-button">Close</a>
        </div>
    </div>
</body>
</html>


